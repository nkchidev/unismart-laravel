<?php $__env->startSection('content'); ?>
    <div id="content" class="container-fluid">
        <?php if(session('status')): ?>
            <div class="alert alert-success">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>
        <div class="card">
            <div class="card-header font-weight-bold d-flex justify-content-between align-items-center">
                <h5 class="m-0 ">Danh sách đơn hàng</h5>
                <div class="form-search form-inline">
                    <form action="#">
                        <input type="text" name="keyword" value="<?php echo e(request()->input('keyword')); ?>" class="form-control form-search" placeholder="Tìm kiếm">
                        <input type="hidden" name="status" value="<?php echo e(request()->input('status')); ?>">
                        <input type="submit" name="btn-search" value="Tìm kiếm" class="btn btn-primary">
                    </form>
                </div>
            </div>
            <div class="card-body">
                <div class="analytic">
                    <a href="<?php echo e(url('admin/order/list?status=processing')); ?>" class="text-primary">Đang xử lý<span class="text-muted">(<?php echo e($count[0]); ?>)</span></a>
                    <a href="<?php echo e(url('admin/order/list?status=being_transported')); ?>" class="text-primary">Đang vận chuyển<span class="text-muted">(<?php echo e($count[1]); ?>)</span></a>
                    <a href="<?php echo e(url('admin/order/list?status=success')); ?>" class="text-primary">Hoàn thành<span class="text-muted">(<?php echo e($count[2]); ?>)</span></a>
                    <a href="<?php echo e(url('admin/order/list?status=cancelled')); ?>" class="text-primary">Đã hủy<span class="text-muted">(<?php echo e($count[3]); ?>)</span></a>
                </div>
                <form action="<?php echo e(url('admin/order/action')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-action form-inline py-3">
                        <select class="form-control mr-1" id="act" name="act">
                            <option>Chọn</option>
                            <?php $__currentLoopData = $list_act; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <input type="submit" name="btn-search" value="Áp dụng" class="btn btn-primary">
                    </div>
                    <table class="table table-striped table-checkall">
                        <thead>
                            <tr>
                                <th>
                                    <input type="checkbox" name="checkall">
                                </th>
                                <th scope="col">#</th>
                                <th scope="col">Mã đơn hàng</th>
                                <th scope="col">Khách hàng</th>
                                <th scope="col">Số lượng</th>
                                <th scope="col">Tổng tiền</th>
                                <th scope="col">Trạng thái</th>
                                <th scope="col">Thời gian</th>
                                <th scope="col">Chi tiết</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($orders->total() > 0): ?>
                                <?php
                                    $temp = 0;
                                ?>
                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <input name="list_check[]" value="<?php echo e($order->id); ?>" type="checkbox">
                                        </td>
                                        <td><?php echo e(++$temp); ?></td>
                                        <td><?php echo e($order->id); ?></td>
                                        <td><?php echo e($order->guest->fullname); ?> <br>
                                            <?php echo e($order->guest->phone_number); ?>

                                        </td>
                                        <td><?php echo e($order->num_order); ?></td>
                                        <td><?php echo e(number_format($order->total, 0,'','.')); ?>đ</td>
                                        <td>
                                            <?php if($order->status == "processing"): ?>
                                                <span class="badge badge-warning">Đang xử lý</span>
                                            <?php elseif($order->status == "being_transported"): ?>
                                                <span class="badge badge-primary">Đang vận chuyển</span>
                                            <?php elseif($order->status == "cancelled"): ?>
                                                <span class="badge badge-dark">Đã hủy</span>
                                            <?php else: ?>
                                                <span class="badge badge-success">Hoàn thành</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($order->created_at); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('order.detail', $order->id)); ?>" class="text-primary">Chi tiết</a>
                                        </td>
                                        
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="9">Không tìm thấy đơn hàng cần tìm</td>
                                </tr>
                            <?php endif; ?>

                        </tbody>
                    </table>
                </form>
                <?php echo e($orders->appends(request()->input())->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\unismart\resources\views/admin/order/show.blade.php ENDPATH**/ ?>