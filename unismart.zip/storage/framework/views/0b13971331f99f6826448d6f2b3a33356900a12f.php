<?php $__env->startSection('content'); ?>
    <div id="main-content-wp" class="cart-page">
        <div class="section" id="breadcrumb-wp">
            <div class="wp-inner">
                <div class="section-detail">
                    <ul class="list-item clearfix">
                        <li>
                            <a href="?page=home" title="">Trang chủ</a>
                        </li>
                        <li>
                            <a href="" title="">Giỏ hàng</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <?php if(Cart::count()): ?>
            <div id="wrapper" class="wp-inner clearfix">
                <div class="section" id="info-cart-wp">
                    <div class="section-detail table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <td>Số thứ tự</td>
                                    <td>Ảnh sản phẩm</td>
                                    <td>Tên sản phẩm</td>
                                    <td>Giá sản phẩm</td>
                                    <td>Số lượng</td>
                                    <td colspan="2">Thành tiền</td>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $temp = 0;
                                ?>
                                <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(++$temp); ?></td>
                                        <td>
                                            <a href="" title="" class="thumb">
                                                <img style="height: 100px;; object-fit: cover" src="<?php echo e(url($item->options->thumbnail)); ?>" alt="">
                                            </a>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('product.detail', $item->id)); ?>" title="" class="name-product"><?php echo e($item->name); ?></a>
                                        </td>
                                        <td><?php echo e(number_format($item->price,0, '','.')); ?>đ</td>
                                        <td>
                                            <input type="number" name="num-order" data-id="<?php echo e($item->rowId); ?>" min="1" value="<?php echo e($item->qty); ?>" class="num-order">
                                        </td>
                                        <td id="sub_total_<?php echo e($item->rowId); ?>"><?php echo e(number_format($item->total , 0, '' , '.')); ?>đ</td>
                                        <td>
                                            <a href="<?php echo e(route('cart.delete', $item->rowId)); ?>" title="" class="del-product"><i class="fa fa-trash-o"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="7">
                                        <div class="clearfix">
                                            <p id="total-price" class="fl-right">Tổng giá: <span class="total"><?php echo e(number_format(Cart::total(),0,'','.')); ?>đ</span></p>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="7">
                                        <div class="clearfix">
                                            <div class="fl-right">
                                                
                                                <a href="<?php echo e(route('checkout.show')); ?>" title="" id="checkout-cart">Thanh toán</a>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
                <div class="section" id="action-cart-wp">
                    <div class="section-detail">
                        
                        <a href="<?php echo e(url('home')); ?>" title="" id="buy-more">Mua tiếp</a><br />
                        <a href="<?php echo e(route('cart.destroy')); ?>" title="" id="delete-cart">Xóa giỏ hàng</a>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <div id="wrapper" class="wp-inner clearfix">
                <div class="section" id="action-cart-wp">
                    <div class="section-detail">
                        <a href="<?php echo e(url('home')); ?>" title="" id="buy-more">Mua tiếp</a><br />
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\unismart\resources\views/guest/cart/show.blade.php ENDPATH**/ ?>