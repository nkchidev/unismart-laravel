<?php $__env->startSection('content'); ?>
    <div class="container-fluid py-5">
        <div class="row">
            <div class="col">
                <div class="card text-white bg-primary mb-3" style="max-width: 18rem;">
                    <div class="card-header">ĐƠN HÀNG THÀNH CÔNG</div>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($count[0]); ?></h5>
                        <p class="card-text">Đơn hàng giao dịch thành công</p>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card text-white bg-danger mb-3" style="max-width: 18rem;">
                    <div class="card-header">ĐANG XỬ LÝ</div>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($count[1]); ?></h5>
                        <p class="card-text">Số lượng đơn hàng đang xử lý</p>
                    </div>
                </div>
            </div>

            <div class="col">
                <div class="card text-white bg-success mb-3" style="max-width: 18rem;">
                    <div class="card-header">DOANH SỐ</div>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e(number_format($sales,0,'','.')); ?>đ</h5>
                        <p class="card-text">Doanh số hệ thống</p>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card text-white bg-dark mb-3" style="max-width: 18rem;">
                    <div class="card-header">ĐƠN HÀNG HỦY</div>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($count[2]); ?></h5>
                        <p class="card-text">Số đơn bị hủy trong hệ thống</p>
                    </div>
                </div>
            </div>
        </div>
        <!-- end analytic  -->
        <div class="card">
            <div class="card-header font-weight-bold">
                ĐƠN HÀNG MỚI
            </div>
            <div class="card-body">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Mã</th>
                            <th scope="col">Khách hàng</th>
                            <th scope="col">Số lượng</th>
                            <th scope="col">Tổng tiền</th>
                            <th scope="col">Trạng thái</th>
                            <th scope="col">Thời gian</th>
                            <th scope="col">Chi tiết</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $temp = 0;
                        ?>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e(++$temp); ?></th>
                                <td><?php echo e($order->id); ?></td>
                                <td>
                                    <?php echo e($order->guest->fullname); ?> <br>
                                    <?php echo e($order->guest->phone_number); ?>

                                </td>
                                <td><?php echo e($order->num_order); ?></td>
                                <td><?php echo e(number_format($order->total,0,'','.')); ?>đ</td>
                                <td>
                                    <?php if($order->status == "processing"): ?>
                                                <span class="badge badge-warning">Đang xử lý</span>
                                            <?php elseif($order->status == "being_transported"): ?>
                                                <span class="badge badge-primary">Đang vận chuyển</span>
                                            <?php elseif($order->status == "cancelled"): ?>
                                                <span class="badge badge-dark">Đã hủy</span>
                                            <?php else: ?>
                                                <span class="badge badge-success">Hoàn thành</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($order->created_at); ?></td>
                                <td>
                                    <a href="<?php echo e(route('order.detail', $order->id)); ?>" class="text-primary">Chi tiết</a>
                                </td>
                                
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo e($orders->links()); ?>

            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\unismart\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>