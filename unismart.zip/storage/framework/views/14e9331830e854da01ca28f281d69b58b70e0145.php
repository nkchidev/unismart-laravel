<?php $__env->startSection('content'); ?>
    <div id="main-content-wp" class="clearfix blog-page">
        <div class="wp-inner">
            <div class="secion" id="breadcrumb-wp">
                <div class="secion-detail">
                    <ul class="list-item clearfix">
                        <li>
                            <a href="" title="">Trang chủ</a>
                        </li>
                        <li>
                            <a href="" title="">Blog</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="main-content fl-right">
                <div class="section" id="list-blog-wp">
                    <div class="section-head clearfix">
                        <h3 class="section-title">Blog</h3>
                    </div>
                    <div class="section-detail">
                        <ul class="list-item">
                            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="clearfix">
                                    <a href="<?php echo e(url("tin-tuc/{$post->category->slug}/{$post->slug}/{$post->id}")); ?>" title="" class="thumb fl-left">
                                        <img src="<?php echo e(url($post->post_thumb)); ?>" alt="">
                                    </a>
                                    <div class="info fl-right">
                                        <a href="?page=detail_blog" title="" class="title"><?php echo e($post->title); ?></a>
                                        <?php if($post->created_at != null): ?>
                                            <span class="create-date"><?php echo e($post->created_at); ?></span>
                                        <?php endif; ?>
                                        
                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
                <div class="section float-right" id="paging-wp">
                    <?php echo e($posts->links()); ?>

                </div>
            </div>
            <div class="sidebar fl-left">
                <?php echo $__env->make('partials.celling', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('partials.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\unismart\resources\views/guest/post/show.blade.php ENDPATH**/ ?>