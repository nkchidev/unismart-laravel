<?php $__env->startSection('content'); ?>
    <div id="content" class="container-fluid">
        <div class="card">
            <div class="card-header font-weight-bold">
                Thông tin đơn hàng
            </div>
            <div class="card-body">
                <p class="cart-text font-weight-bold">Mã đơn hàng</p>
                <p class="card-text"><?php echo e($order->id); ?></p>
                <p class="cart-text font-weight-bold">Địa chỉ nhận hàng</p>
                <p class="card-text"><?php echo e($order->guest->ship_address); ?></p>
                <p class="cart-text font-weight-bold">Số điện thoại</p>
                <p class="card-text"><?php echo e($order->guest->phone_number); ?></p>
                <p class="cart-text font-weight-bold">Email</p>
                <p class="card-text"><?php echo e($order->guest->email); ?></p>
                <p class="cart-text font-weight-bold">Thông tin vận chuyển</p>
                <p class="card-text"><?php echo e($order->status == "home_payment" ? "Thanh toán tại nhà": "Thanh toán tại cửa hàng"); ?></p>
                <form action="<?php echo e(route('order.edit', $order->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="status" class="cart-text font-weight-bold">Tình trạng đơn hàng</label>
                        <select name="status" id="status" class="form-control">
                            <option <?php echo e($order->status == "processing" ? "selected" : ''); ?> value="processing">Đang xử lý</option>
                            <option <?php echo e($order->status == "being_transported" ? "selected" : ''); ?> value="being_transported">Đang vận chuyển</option>
                            <option <?php echo e($order->status == "success" ? "selected" : ''); ?> value="success">Thành công</option>
                            <option <?php echo e($order->status == "cancelled" ? "selected" : ''); ?> value="cancelled">Hủy đơn hàng</option>
                        </select>
                    </div>
                    <input type="submit" value="Cập nhật đơn hàng" name="btn_update" class="btn btn-primary">
                </form>
                <p class="card-text font-weight-bold text-uppercase mt-3">Sản phẩm đơn hàng</p>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Ảnh sản phẩm</th>
                            <th scope="col">Tên sản phẩm</th>
                            <th scope="col">Đơn giá</th>
                            <th scope="col">Số lượng</th>
                            <th scope="col">Thành tiền</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $temp = 0;
                        ?>
                        <?php $__currentLoopData = $order->order_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e(++$temp); ?></th>
                                <td>
                                    <img src="<?php echo e(url($item->product->avatar)); ?>" style="width: 150px; height: 100px" alt="">
                                </td>
                                <td><?php echo e($item->product->name); ?></td>
                                <td><?php echo e(number_format($item->price,0,'','.')); ?>đ</td>
                                <td><?php echo e($item->quantity); ?></td>
                                <td><?php echo e(number_format($item->total,0,'','.')); ?>đ</td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div class="section pt-3 pb-3">
                    <p class="card-text font-weight-bold text-uppercase mt-3">Giá trị đơn hàng</p>
                    <div class="row">
                        <div class="col-2 text-right">Tổng số lượng:</div>
                        <div class="col-10"><?php echo e($order->num_order); ?> sản phẩm</div>
                    </div>
                    <div class="row text-danger font-weight-bold">
                        <div class="col-2 text-right">Tổng đơn hàng: </div>
                        <div class="col-10"><?php echo e(number_format($order->total)); ?>đ</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\unismart\resources\views/admin/order/detail.blade.php ENDPATH**/ ?>