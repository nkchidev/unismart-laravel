<?php $__env->startSection('content'); ?>
    <div id="main-content-wp" class="clearfix category-product-page">
        <div class="wp-inner">
            <div class="secion" id="breadcrumb-wp">
                <div class="secion-detail">
                    <ul class="list-item clearfix">
                        <li>
                            <a href="" title="">Trang chủ</a>
                        </li>
                        <li>
                            <a href="" title="">Tìm kiếm</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="main-content fl-right">
                <div class="section" id="list-product-wp">
                    <div class="section-head clearfix">
                        <h3 class="section-title fl-left">Tìm kiếm</h3>
                        
                    </div>
                    <?php if($list_product->count()): ?>
                        <div class="section-detail">
                            <ul class="list-item clearfix">
                                <?php $__currentLoopData = $list_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a href="<?php echo e(route('product.detail', $product->id)); ?>" title="" class="thumb">
                                            <img style="height: 150px; width: auto" src="<?php echo e(url($product->avatar)); ?>">
                                        </a>
                                        <a href="<?php echo e(route('product.detail', $product->id)); ?>" title="" class="product-name"><?php echo e($product->name); ?></a>
                                        <div class="price">
                                            <span class="new"><?php echo e(number_format($product->price,0,'','.')); ?>đ</span>
                                            
                                        </div>
                                        <div class="action clearfix">
                                            <a href="<?php echo e(route('cart.add', $product->id)); ?>" title="Thêm giỏ hàng" class="add-cart fl-left">Thêm giỏ hàng</a>
                                            <a href="<?php echo e(route('product.detail', $product->id)); ?>" title="Mua ngay" class="buy-now fl-right">Mua ngay</a>
                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-warning">Không tìm thấy sản phẩm cần tìm</div>
                    <?php endif; ?>

                </div>
                <div class="section float-right" id="paging-wp">
                    <?php echo e($list_product->links()); ?>

                </div>
            </div>
            <div class="sidebar fl-left">
                <?php echo $__env->make('partials.category', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('partials.filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('partials.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\unismart\resources\views/guest/product/search.blade.php ENDPATH**/ ?>