<div class="section" id="banner-wp">
    <div class="section-detail">
        <a href="" title="" class="thumb">
            <img src="<?php echo e(asset('images/banner.png')); ?>" alt="">
        </a>
    </div>
</div>
<?php /**PATH F:\xampp\htdocs\unismart\resources\views/partials/banner.blade.php ENDPATH**/ ?>