<?php $__env->startSection('content'); ?>
    <div id="main-content-wp" class="clearfix detail-product-page">
        <div class="wp-inner">
            <div class="secion" id="breadcrumb-wp">
                <div class="secion-detail">
                    <ul class="list-item clearfix">
                        <li>
                            <a href="" title="">Trang chủ</a>
                        </li>
                        <li>
                            <a href="" title="">Điện thoại</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="main-content fl-right">
                <div class="section" id="detail-product-wp">
                    <div class="section-detail clearfix">
                        <div class="thumb-wp fl-left">
                            <a href="" title="" id="main-thumb">
                                <img style="width: 350px; height: 350px; max-width: 350px; min-width: 350px;" id="zoom" src="<?php echo e(url($product->avatar)); ?>"
                                    data-zoom-image="<?php echo e(url($product->avatar)); ?>" />
                            </a>
                            <div id="list-thumb">
                                <a href="" data-image="<?php echo e(url($product->avatar)); ?>" data-zoom-image="<?php echo e(url($product->avatar)); ?>">
                                    <img style="width: 70px; height: 70px; max-width: 70px; min-width: 70px; object-fit: cover;" id="zoom"
                                    src="<?php echo e(url($product->avatar)); ?>" />
                                </a>
                                <?php $__currentLoopData = $product->product_image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="" data-image="<?php echo e(url($value->link_image)); ?>" data-zoom-image="<?php echo e(url($value->link_image)); ?>">
                                        <img style="width: 70px; height: 70px; max-width: 70px; min-width: 70px; object-fit: cover;" id="zoom"
                                        src="<?php echo e(url($value->link_image)); ?>" />
                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <div class="thumb-respon-wp fl-left">
                            <img src="public/images/img-pro-01.png" alt="">
                        </div>
                        <form action="<?php echo e(route('cart.add', $product->id)); ?>" method="GET">
                            <div class="info fl-right">
                                <h3 class="product-name"><?php echo e($product->name); ?></h3>
                                <div class="desc">
                                    <?php echo $product->describe; ?>

                                </div>
                                <div class="num-product">
                                    <span class="title">Sản phẩm: </span>
                                    <span class="status"><?php echo e($product->product_status == "stocking" ? 'Còn hàng' : 'Hết hàng'); ?></span>
                                </div>
                                <p class="price"><?php echo e(number_format($product->price,0,'','.')); ?>đ </p>
                                <div id="num-order-wp">
                                    <span style="color: #666">Số lượng: </span>
                                    <a title="" id="minus"><i class="fa fa-minus"></i></a>
                                    <input type="text" name="num_order" value="1" id="num-order">
                                    <a title="" id="plus"><i class="fa fa-plus"></i></a>
                                </div>
                                <input type="submit" title="Thêm giỏ hàng" class="add-cart" style="border: none" value="Thêm giỏ hàng"/>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="section" id="post-product-wp">
                    <div class="section-head">
                        <h3 class="section-title">Mô tả sản phẩm</h3>
                    </div>
                    <div class="section-detail">
                        <?php echo $product->detail; ?>

                    </div>
                </div>
                <?php echo $__env->make('partials.same_category', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="sidebar fl-left">
                <?php echo $__env->make('partials.category', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('partials.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\unismart\resources\views/guest/product/detail.blade.php ENDPATH**/ ?>