<!DOCTYPE html>
<html>

<head>
    <title>ISMART STORE</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link href="<?php echo e(asset('css/bootstrap/bootstrap-theme.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('css/bootstrap/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('reset.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('css/carousel/owl.carousel.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('css/carousel/owl.theme.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('css/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('style.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('responsive.css')); ?>" rel="stylesheet" type="text/css" />
    
    <script src="<?php echo e(asset('js/jquery-2.2.4.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('js/elevatezoom-master/jquery.elevatezoom.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('js/bootstrap/bootstrap.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('js/carousel/owl.carousel.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('js/main.js')); ?>" type="text/javascript"></script>
</head>

<body>
    <div id="site">
        <div id="container">
            <div id="header-wp">
                <div id="head-top" class="clearfix">
                    <div class="wp-inner">
                        <a href="" title="" id="payment-link" class="fl-left">Hình thức thanh toán</a>
                        <div id="main-menu-wp" class="fl-right">
                            <ul id="main-menu" class="clearfix">
                                <li>
                                    <a href="<?php echo e(url('home')); ?>" title="">Trang chủ</a>
                                </li>
                                
                                <li>
                                    <a href="<?php echo e(url('tin-tuc')); ?>" title="">Tin tức</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('page.about', 1)); ?>" title="">Giới thiệu</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('page.contact', 2)); ?>" title="">Liên hệ</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div id="head-body" class="clearfix">
                    <div class="wp-inner">
                        <a href="<?php echo e(url('home')); ?>" title="" id="logo" class="fl-left"><img
                                src="<?php echo e(asset('images/logo.png')); ?>" /></a>
                        <div id="search-wp" class="fl-left">
                            <form method="POST" action="<?php echo e(url('san-pham/tim-kiem')); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="text" name="keyword" id="s"
                                    placeholder="Nhập từ khóa tìm kiếm tại đây!">
                                <button type="submit" id="sm-s">Tìm kiếm</button>
                            </form>
                        </div>
                        <div id="action-wp" class="fl-right">
                            <div id="advisory-wp" class="fl-left">
                                <span class="title">Tư vấn</span>
                                <span class="phone">0987.654.321</span>
                            </div>
                            <div id="btn-respon" class="fl-right"><i class="fa fa-bars" aria-hidden="true"></i></div>
                            <a href="?page=cart" title="giỏ hàng" id="cart-respon-wp" class="fl-right">
                                <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                                <span id="num"><?php echo e(Cart::count()); ?></span>
                            </a>
                            <div id="cart-wp" class="fl-right">
                                <div id="btn-cart">
                                    <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                                    <span id="num"><?php echo e(Cart::count()); ?></span>
                                </div>
                                <?php if(Cart::count()): ?>
                                    <div id="dropdown">
                                        <p class="desc">Có <span><?php echo e(Cart::count()); ?> sản phẩm</span> trong giỏ hàng
                                        </p>
                                        <ul class="list-cart">
                                            <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="clearfix">
                                                    <a href="" title="" class="thumb fl-left">
                                                        <img src="<?php echo e(url($item->options->thumbnail)); ?>"
                                                            alt="">
                                                    </a>
                                                    <div class="info fl-right">
                                                        <a href="" title=""
                                                            class="product-name"><?php echo e($item->name); ?></a>
                                                        <p class="price"><?php echo e(number_format($item->price, 0, '', '.')); ?>đ
                                                        </p>
                                                        <p class="qty">Số lượng:
                                                            <span><?php echo e(number_format($item->qty)); ?></span></p>
                                                    </div>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                        <div class="total-price clearfix">
                                            <p class="title fl-left">Tổng:</p>
                                            <p class="price fl-right"><?php echo e(number_format(Cart::total(), 0, '', '.')); ?>đ
                                            </p>
                                        </div>
                                        <div class="action-cart clearfix">
                                            <a href="<?php echo e(route('cart.show')); ?>" title="Giỏ hàng"
                                                class="view-cart fl-left">Giỏ hàng</a>
                                            <a href="<?php echo e(route('checkout.show')); ?>" title="Thanh toán"
                                                class="checkout fl-right">Thanh toán</a>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
<?php /**PATH F:\xampp\htdocs\unismart\resources\views/partials/header.blade.php ENDPATH**/ ?>