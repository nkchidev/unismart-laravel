<div class="section" id="selling-wp">
    <div class="section-head">
        <h3 class="section-title">Sản phẩm bán chạy</h3>
    </div>
    <?php if($list_product->count()): ?>
        <div class="section-detail">
            <ul class="list-item">
                <?php $__currentLoopData = $list_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($value->celling == "yes" && $value->status == "public"): ?>
                        <li class="clearfix">
                            <a href="<?php echo e(route('product.detail', $value->id)); ?>" title="" class="thumb fl-left">
                                <img src="<?php echo e(url($value->avatar)); ?>" alt="">
                            </a>
                            <div class="info fl-right">
                                <a href="<?php echo e(route('product.detail', $value->id)); ?>" title="" class="product-name"><?php echo e($value->name); ?></a>
                                <div class="price">
                                    <span class="new"><?php echo e(number_format($value->price,0,'','.')); ?>đ</span>
                                    
                                </div>
                                <a href="<?php echo e(route('product.detail', $value->id)); ?>" title="" class="buy-now">Mua ngay</a>
                            </div>
                        </li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
</div>
<?php /**PATH F:\xampp\htdocs\unismart\resources\views/partials/celling.blade.php ENDPATH**/ ?>