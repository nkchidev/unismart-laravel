<div class="sidebar fl-left">
    <div class="section" id="selling-wp">
        <div class="section-head">
            <h3 class="section-title">Sản phẩm bán chạy</h3>
        </div>
        <div class="section-detail">
            <ul class="list-item">
                <li class="clearfix">
                    <a href="?page=detail_product" title="" class="thumb fl-left">
                        <img src="<?php echo e(asset('images/img-pro-13.png')); ?>" alt="">
                    </a>
                    <div class="info fl-right">
                        <a href="?page=detail_product" title="" class="product-name">Laptop Asus A540UP I5</a>
                        <div class="price">
                            <span class="new">5.190.000đ</span>
                            <span class="old">7.190.000đ</span>
                        </div>
                        <a href="" title="" class="buy-now">Mua ngay</a>
                    </div>
                </li>
                <li class="clearfix">
                    <a href="?page=detail_product" title="" class="thumb fl-left">
                        <img src="<?php echo e(asset('images/img-pro-11.png')); ?>" alt="">
                    </a>
                    <div class="info fl-right">
                        <a href="?page=detail_product" title="" class="product-name">Iphone X Plus</a>
                        <div class="price">
                            <span class="new">15.190.000đ</span>
                            <span class="old">17.190.000đ</span>
                        </div>
                        <a href="" title="" class="buy-now">Mua ngay</a>
                    </div>
                </li>
                <li class="clearfix">
                    <a href="?page=detail_product" title="" class="thumb fl-left">
                        <img src="<?php echo e(asset('images/img-pro-12.png')); ?>" alt="">
                    </a>
                    <div class="info fl-right">
                        <a href="?page=detail_product" title="" class="product-name">Iphone X Plus</a>
                        <div class="price">
                            <span class="new">15.190.000đ</span>
                            <span class="old">17.190.000đ</span>
                        </div>
                        <a href="" title="" class="buy-now">Mua ngay</a>
                    </div>
                </li>
                <li class="clearfix">
                    <a href="?page=detail_product" title="" class="thumb fl-left">
                        <img src="<?php echo e(asset('images/img-pro-05.png')); ?>" alt="">
                    </a>
                    <div class="info fl-right">
                        <a href="?page=detail_product" title="" class="product-name">Iphone X Plus</a>
                        <div class="price">
                            <span class="new">15.190.000đ</span>
                            <span class="old">17.190.000đ</span>
                        </div>
                        <a href="" title="" class="buy-now">Mua ngay</a>
                    </div>
                </li>
                <li class="clearfix">
                    <a href="?page=detail_product" title="" class="thumb fl-left">
                        <img src="<?php echo e(asset('images/img-pro-22.png')); ?>" alt="">
                    </a>
                    <div class="info fl-right">
                        <a href="?page=detail_product" title="" class="product-name">Iphone X Plus</a>
                        <div class="price">
                            <span class="new">15.190.000đ</span>
                            <span class="old">17.190.000đ</span>
                        </div>
                        <a href="" title="" class="buy-now">Mua ngay</a>
                    </div>
                </li>
                <li class="clearfix">
                    <a href="?page=detail_product" title="" class="thumb fl-left">
                        <img src="<?php echo e(asset('images/img-pro-23.png')); ?>" alt="">
                    </a>
                    <div class="info fl-right">
                        <a href="?page=detail_product" title="" class="product-name">Iphone X Plus</a>
                        <div class="price">
                            <span class="new">15.190.000đ</span>
                            <span class="old">17.190.000đ</span>
                        </div>
                        <a href="" title="" class="buy-now">Mua ngay</a>
                    </div>
                </li>
                <li class="clearfix">
                    <a href="?page=detail_product" title="" class="thumb fl-left">
                        <img src="<?php echo e(asset('images/img-pro-18.png')); ?>" alt="">
                    </a>
                    <div class="info fl-right">
                        <a href="?page=detail_product" title="" class="product-name">Iphone X Plus</a>
                        <div class="price">
                            <span class="new">15.190.000đ</span>
                            <span class="old">17.190.000đ</span>
                        </div>
                        <a href="" title="" class="buy-now">Mua ngay</a>
                    </div>
                </li>
                <li class="clearfix">
                    <a href="?page=detail_product" title="" class="thumb fl-left">
                        <img src="<?php echo e(asset('images/img-pro-15.png')); ?>" alt="">
                    </a>
                    <div class="info fl-right">
                        <a href="?page=detail_product" title="" class="product-name">Iphone X Plus</a>
                        <div class="price">
                            <span class="new">15.190.000đ</span>
                            <span class="old">17.190.000đ</span>
                        </div>
                        <a href="" title="" class="buy-now">Mua ngay</a>
                    </div>
                </li>
            </ul>
        </div>
    </div>
    <div class="section" id="banner-wp">
        <div class="section-detail">
            <a href="?page=detail_product" title="" class="thumb">
                <img src="<?php echo e(asset('images/banner.png')); ?>" alt="">
            </a>
        </div>
    </div>
</div>
<?php /**PATH F:\xampp\htdocs\unismart\resources\views/partials/sidebar-blog.blade.php ENDPATH**/ ?>