<div class="section" id="same-category-wp">
    <div class="section-head">
        <h3 class="section-title">Cùng chuyên mục</h3>
    </div>
    <div class="section-detail">
        <ul class="list-item">
            <?php $__currentLoopData = $same_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <a href="" title="" class="thumb">
                        <img style="height: 150px; width: auto" src="<?php echo e(url($item->avatar)); ?>">
                    </a>
                    <a href="" title="" class="product-name"><?php echo e($item->name); ?></a>
                    <div class="price">
                        <span class="new"><?php echo e(number_format($item->price, 0, '','.')); ?>đ</span>
                        
                    </div>
                    <div class="action clearfix">
                        <a href="<?php echo e(route('cart.add', $item->id)); ?>" title="" class="add-cart fl-left">Thêm giỏ hàng</a>
                        <a href="<?php echo e(route('product.detail',$item->id)); ?>" title="" class="buy-now fl-right">Mua ngay</a>
                    </div>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div>
<?php /**PATH F:\xampp\htdocs\unismart\resources\views/partials/same_category.blade.php ENDPATH**/ ?>