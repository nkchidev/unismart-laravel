<div class="sidebar fl-left">
    @include('partials.category')
    @include('partials.celling')
    @include('partials.banner')
</div>

