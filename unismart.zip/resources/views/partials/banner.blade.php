<div class="section" id="banner-wp">
    <div class="section-detail">
        <a href="" title="" class="thumb">
            <img src="{{ asset('images/banner.png') }}" alt="">
        </a>
    </div>
</div>
