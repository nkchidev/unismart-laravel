@extends('layouts.guest')

@section('content')
    <div id="main-content-wp" class="checkout-page">
        <div id="wrapper" class="wp-inner clearfix">
            <div class="content-order text-center" style="min-height: 200px">
                <h1 style="margin: 10px" class="h1 text-primary">Đặt hàng thành công</h1>
                <h5 class="h5">Cảm ơn quý khách đã lựa chọn sản phẩm của cửa hàng Unismart và cho chúng tôi được phục vụ quý
                    khách</h5>
                <h5 class="h5">Tổng đài viên Ismart sẽ liên hệ đến quý khách trong thời gian sớm nhất để xác nhận đơn hàng</h5>
            </div>
        </div>
    </div>
@endsection
